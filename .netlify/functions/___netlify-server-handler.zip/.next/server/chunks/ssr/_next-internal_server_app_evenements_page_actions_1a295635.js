module.exports=[34377,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_evenements_page_actions_1a295635.js.map